# SELinux Permissive & Hide

This Magisk module switches SELinux to **permissive mode** during the boot process and hides the change to help bypass SafetyNet checks.

> ⚠️ **Warning:**  
> This module intentionally lowers the security settings of your device.  
> Do **NOT** use it unless you fully understand the potential risks.

---

## Important Notes

- This module **will NOT work** if your kernel is compiled with an always-enforcing SELinux policy (e.g., most stock Samsung kernels).
- Using permissive mode reduces device security and may expose you to vulnerabilities.

---

## Installation Instructions

### Stable Release

1. Download the latest `selinux_permissive_hider.zip` from the [Releases page](https://github.com/SHAJON-404/SELinux-Magisk-Module/releases).

2. Open **Magisk Manager** and navigate to **Modules**.

3. Tap on the **+ (plus)** button or **Downloads**, then select the downloaded ZIP file.

4. Install the module and **Reboot** your device.

---

## Features

- Automatically sets SELinux to permissive mode on boot.
- Masks SELinux status to avoid detection by SafetyNet and similar services.
- Lightweight and easy to uninstall via Magisk Manager.

---

## Support & Contributions

For issues, suggestions, or contributions, please open an issue or pull request on the [GitHub repository](https://github.com/SHAJON-404/SELinux-Magisk-Module).

---

## License

This project is licensed under the SHAJON PROPRIETARY LICENSE v1.0. See the [LICENSE](LICENSE) file for details.
